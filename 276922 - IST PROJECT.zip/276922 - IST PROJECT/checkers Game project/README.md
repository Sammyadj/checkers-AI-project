# checkers-AI-project
Creating a checkers game to play against an AI agent
