WIDTH, HEIGHT = 800, 800

BLACK = "black"
RED = "red"
WHITE = "white"
GREY = "grey"
GREEN = "green"

ROWS, COLS = 8, 8
SQUARE_SIZE = WIDTH // COLS

CROWN = "assets/crown.png"
